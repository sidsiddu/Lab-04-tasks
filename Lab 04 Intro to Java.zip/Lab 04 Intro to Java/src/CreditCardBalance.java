public class CreditCardBalance {
    public static void main(String[] args) {
        double initialBalance = 5000.00;
        double interestRate = 0.17;

        double firstMonthInterest = initialBalance * interestRate;
        double firstMonthBalance = initialBalance + firstMonthInterest;

        double secondMonthInterest = firstMonthBalance * interestRate;
        double secondMonthBalance = firstMonthBalance + secondMonthInterest;

        System.out.println("The interest after one month is: " + firstMonthInterest);
        System.out.println("The balance after one month is: " + firstMonthBalance);
        System.out.println("The interest after two months is: " + secondMonthInterest);
        System.out.println("The balance after two months is: " + secondMonthBalance);
    }
}
