public class YearlyMaintenance {
    public static void main(String[] args) {
        double springCost = 111.00;
        double summerCost = 121.00;
        double fallCost = 123.00;
        double winterCost = 100.00;

        double totalCost = springCost + summerCost + fallCost + winterCost;
        System.out.println("The total yearly maintenance cost is: " + totalCost);
    }
}
