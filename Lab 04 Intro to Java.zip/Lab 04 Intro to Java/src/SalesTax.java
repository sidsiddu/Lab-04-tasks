public class SalesTax {
    public static void main(String[] args) {
        double purchasePrice = 123.00;
        double tax = purchasePrice * 0.05;
        System.out.println("The 5% sales tax for a purchase of " + purchasePrice + " is: " + tax);
    }
}
