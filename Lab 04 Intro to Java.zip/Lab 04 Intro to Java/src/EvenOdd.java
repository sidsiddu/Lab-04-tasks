public class EvenOdd {

    public static void main(String[] args) {
        int numToExamine = 100;
        if (numToExamine % 2 == 0) {
            System.out.println("The number " + numToExamine + " is even.");
        } else {
            System.out.println("The number " + numToExamine + " is odd.");
        }
    }
}
